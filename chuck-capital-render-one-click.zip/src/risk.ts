import { config } from './config';

export type RiskState = {
  exposureUsd: number;
  openPositions: number;
  openOrders: number;
  dailyRealizedLossUsd: number;
};

export function approveTrade(notionalUsd: number, score: number, spreadBps: number, state: RiskState) {
  if (notionalUsd < config.minTradeUsd) return { ok: false, reason: `Below minimum trade size $${config.minTradeUsd.toFixed(2)}` };
  if (notionalUsd > config.maxTradeUsd) return { ok: false, reason: `Above per-trade cap $${config.maxTradeUsd.toFixed(2)}` };
  if (state.exposureUsd + notionalUsd > config.maxExposureUsd) return { ok: false, reason: 'Aggregate exposure cap' };
  if (state.openPositions >= config.maxConcurrentPositions) return { ok: false, reason: 'Concurrent position cap' };
  if (state.openOrders >= config.maxOpenOrders) return { ok: false, reason: 'Open order cap' };
  if (spreadBps > config.maxSpreadBps) return { ok: false, reason: 'Spread too wide' };
  if (score < config.minSignalScore) return { ok: false, reason: 'Signal score below threshold' };
  if (state.dailyRealizedLossUsd >= config.dailyLossLimitUsd) return { ok: false, reason: 'Daily loss circuit breaker' };
  return { ok: true, reason: 'Approved' };
}

export function chooseNotional(expectedNetEdgeUsd: number, maxAllowedUsd: number) {
  // Never trade merely because the signal exists. Require a positive modeled net edge
  // after estimated spread/fees/slippage. Start at $1 and scale only when the model
  // supports a larger size within risk limits.
  if (!(expectedNetEdgeUsd > 0)) return 0;
  return Math.min(config.maxTradeUsd, Math.max(config.minTradeUsd, maxAllowedUsd));
}
