import 'dotenv/config';

export const config = {
  dryRun: process.env.DRY_RUN !== 'false',
  pollIntervalMs: Number(process.env.POLL_INTERVAL_MS ?? 15000),
  strategyRefreshMs: Number(process.env.STRATEGY_REFRESH_MS ?? 3600000),
  minTradeUsd: Number(process.env.MIN_TRADE_USD ?? 1),
  maxTradeUsd: Number(process.env.MAX_TRADE_USD ?? 10),
  maxExposureUsd: Number(process.env.MAX_TOTAL_EXPOSURE_USD ?? 100),
  maxConcurrentPositions: Number(process.env.MAX_CONCURRENT_POSITIONS ?? 10),
  maxOpenOrders: Number(process.env.MAX_OPEN_ORDERS ?? 10),
  maxSpreadBps: Number(process.env.MAX_SPREAD_BPS ?? 80),
  minSignalScore: Number(process.env.MIN_SIGNAL_SCORE ?? 0.72),
  cooldownMs: Number(process.env.SYMBOL_COOLDOWN_MS ?? 60000),
  dailyLossLimitUsd: Number(process.env.DAILY_REALIZED_LOSS_LIMIT_USD ?? 20),
  heartbeatTimeoutMs: Number(process.env.HEARTBEAT_TIMEOUT_MS ?? 90000),
  symbols: ['BTC-USD','ETH-USD','SOL-USD','XRP-USD','DOGE-USD','AVAX-USD','NEAR-USD','SUI-USD']
};
