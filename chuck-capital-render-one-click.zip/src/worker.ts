import { config } from './config';

let stopping = false;
let lastHeartbeat = Date.now();
let lastStrategyRefresh = 0;

process.on('SIGTERM', () => { stopping = true; });
process.on('SIGINT', () => { stopping = true; });

async function cycle() {
  lastHeartbeat = Date.now();

  if (Date.now() - lastStrategyRefresh >= config.strategyRefreshMs) {
    lastStrategyRefresh = Date.now();
    console.log(JSON.stringify({ event: 'strategy_refresh', at: new Date().toISOString() }));
  }

  // Production integration point:
  // 1) fetch fresh Robinhood crypto quotes
  // 2) calculate signal + expected net edge
  // 3) require expected net edge > 0 after estimated spread/fees/slippage
  // 4) size between $1 and $10, never exceeding $100 aggregate exposure
  // 5) preview/review order
  // 6) place with a unique client/ref id
  // 7) reconcile order state and fills
  // 8) retry only transient failures, never blindly duplicate an order
  // 9) persist state and audit log
  console.log(JSON.stringify({ event: 'heartbeat', at: new Date().toISOString(), dryRun: config.dryRun }));
}

async function main() {
  console.log(JSON.stringify({
    event: 'worker_started',
    mode: config.dryRun ? 'DRY_RUN' : 'LIVE',
    pollMs: config.pollIntervalMs,
    minTradeUsd: config.minTradeUsd,
    maxTradeUsd: config.maxTradeUsd,
    maxExposureUsd: config.maxExposureUsd
  }));

  while (!stopping) {
    try {
      await cycle();
    } catch (err) {
      console.error(JSON.stringify({ event: 'cycle_error', error: String(err) }));
    }
    await new Promise(r => setTimeout(r, config.pollIntervalMs));
  }

  console.log(JSON.stringify({ event: 'worker_stopped', at: new Date().toISOString() }));
}

main().catch(err => { console.error(err); process.exit(1); });
