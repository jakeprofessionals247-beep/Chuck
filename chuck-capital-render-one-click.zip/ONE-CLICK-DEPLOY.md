# Chuck Capital — Render One-Click Deployment

This repository is prepared for Render Blueprints and a continuously running Background Worker.

## One-click flow

1. Put this repository in GitHub/GitLab/Bitbucket.
2. Open the repository's README and use the **Deploy to Render** button.
3. Review the Blueprint.
4. Enter the Robinhood secrets directly into Render when prompted.
5. Deploy.

Render's Deploy to Render flow reads `render.yaml` and provisions the declared service. The worker is intentionally configured with `DRY_RUN=true` until the Robinhood integration and deployment are verified.

## Important

This package is **not a live trading system yet**. The current worker contains the production control-plane/scaffolding but the Robinhood order adapter still needs to be connected to the official Robinhood Crypto Trading API before live orders can be sent.

Never put Robinhood private keys, API secrets, passwords, or session tokens in GitHub or in ChatGPT.

## Required secrets

- `ROBINHOOD_API_KEY`
- `ROBINHOOD_API_SECRET`
- `ROBINHOOD_ACCOUNT_ID`

The account ID should be entered only in Render's secret/environment-variable UI.

## Current risk policy

- Minimum trade: $1
- Maximum trade: $10
- Maximum aggregate exposure: $100
- Maximum concurrent positions: 10
- Maximum open orders: 10
- Maximum spread: 80 bps
- Minimum signal score: 0.72
- Symbol cooldown: 60 seconds
- Daily realized-loss circuit breaker: $20
- No forced trades
- Positive modeled net-edge requirement after estimated costs

These limits do not guarantee profit or execution.

## Render button

After this repo is pushed to a Git provider, add this to the repository README, replacing the placeholder repository URL:

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR-USERNAME/YOUR-REPOSITORY)

Render recommends specifying the repository URL explicitly for Deploy to Render buttons.

## Production activation

Keep `DRY_RUN=true` during initial deployment. After the official Robinhood API integration is connected, credentials are validated, order previews/reconciliation are tested, and logs confirm correct behavior, live mode can be considered.

A 24/7 worker requires a paid/persistent Render worker plan; do not use an instance that sleeps for this trading workload.
