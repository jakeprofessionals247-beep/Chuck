# Chuck Capital — Render Deployment

> **Render-ready:** this repository includes `render.yaml` for a continuous background worker.

# Chuck Capital — Persistent 24/7 Rapid Crypto Worker

This release changes the strategy sizing floor to **$1.00**. Chuck may use a trade as small as $1 only when the modeled **net edge is positive after estimated spread, fees, and slippage** and all risk controls pass.

## Important
This repository is deployment-ready, but it is **not itself a hosted 24/7 service**. A persistent runtime (container service, VM, or equivalent) must run it continuously. Do not put Robinhood private credentials in the source tree.

## Risk controls
- Minimum trade: $1.00
- Maximum trade: $10.00
- Maximum aggregate exposure: $100.00
- No forced trades
- Positive-net-edge gate
- Spread filter
- Signal-score threshold
- Open-order/position limits
- Daily loss circuit breaker
- Heartbeat
- Graceful shutdown
- Production order flow should use fresh quotes, idempotent client order IDs, reconciliation, and bounded retries

## 24/7 deployment
Run the Docker container under a production supervisor/orchestrator with automatic restart and health monitoring. Recommended architecture:

Chuck Worker -> Market Data -> Signal/Edge Model -> Risk -> Robinhood Order API -> Fill/Reconciliation -> Persistent State/Audit -> Dashboard

Robinhood's Crypto Trading API supports programmatic crypto orders for U.S. customers. Its trading-pair metadata exposes minimum order amounts/sizes, so the worker should query current pair limits rather than assume every asset accepts the same minimum.

## $1 sizing
A $1 order is deliberately allowed by the policy, but Chuck should skip it if expected net profit is not positive after transaction costs and execution friction. A positive model estimate is not a guarantee of realized profit.

## Live mode
Keep `DRY_RUN=true` until the Robinhood API credentials, permissions, deployment secrets, persistent state, monitoring, and reconciliation have been validated. Then set `DRY_RUN=false` in the deployment secret/configuration store.

Never hard-code or paste private Robinhood keys into source control.
